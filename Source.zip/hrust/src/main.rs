use crossterm::{
    event::{self, Event, KeyCode},
    execute,
    terminal::{disable_raw_mode, enable_raw_mode, EnterAlternateScreen, LeaveAlternateScreen},
};
use ratatui::{
    backend::CrosstermBackend,
    layout::{Constraint, Direction, Layout},
    style::{Color, Modifier, Style},
    widgets::{Block, Borders, Gauge, Row, Table, TableState},
    Terminal,
};
use std::{
    error::Error,
    io,
    time::{Duration, Instant},
};
use sysinfo::{Pid, System};

struct App {
    sys: System,
    table_state: TableState,
    process_list: Vec<(Pid, String, f32, u64)>, 
    warning: Option<Instant>, 
}

impl App {
    fn new() -> Self {
        let mut sys = System::new_all();
        sys.refresh_all();
        let mut app = Self {
            sys,
            table_state: TableState::default(),
            process_list: Vec::new(),
            warning: None,
        };
        app.update_process_list();
        if !app.process_list.is_empty() {
            app.table_state.select(Some(0)); 
        }
        app
    }

    fn update_process_list(&mut self) {
        let mut list: Vec<(Pid, String, f32, u64)> = self
            .sys
            .processes()
            .iter()
            .map(|(pid, process)| {
                (
                    *pid,
                    process.name().to_string(),
                    process.cpu_usage(),
                    process.memory() / 1024 / 1024, // MB
                )
            })
            .collect();

        list.sort_by(|a, b| b.2.partial_cmp(&a.2).unwrap_or(std::cmp::Ordering::Equal));
        self.process_list = list;
    }

    fn update(&mut self) {
        self.sys.refresh_cpu();
        self.sys.refresh_memory();
        self.sys.refresh_processes();
        self.update_process_list();

        
        if let Some(timestamp) = self.warning {
            if timestamp.elapsed() > Duration::from_secs(3) {
                self.warning = None;
            }
        }
    }

    fn next_process(&mut self) {
        if self.process_list.is_empty() { return; }
        let i = match self.table_state.selected() {
            Some(i) => if i >= self.process_list.len() - 1 { 0 } else { i + 1 },
            None => 0,
        };
        self.table_state.select(Some(i));
    }

    fn previous_process(&mut self) {
        if self.process_list.is_empty() { return; }
        let i = match self.table_state.selected() {
            Some(i) => if i == 0 { self.process_list.len() - 1 } else { i - 1 },
            None => 0,
        };
        self.table_state.select(Some(i));
    }

    fn kill_selected_process(&mut self) {
        if let Some(selected_index) = self.table_state.selected() {
            if let Some(proc_info) = self.process_list.get(selected_index) {
                let target_pid = proc_info.0;
                let proc_name = proc_info.1.to_lowercase();

                let protected_tasks = [
                    "svchost.exe", "wininit.exe", "csrss.exe", "smss.exe", 
                    "lsass.exe", "services.exe", "explorer.exe", "winlogon.exe",
                    "ntoskrnl.exe", "spoolsv.exe", "dwm.exe"
                ];

                if protected_tasks.iter().any(|&task| proc_name == task) {
                    self.warning = Some(Instant::now());
                    return; 
                }
                
                if let Some(process) = self.sys.process(target_pid) {
                    let _ = process.kill_with(sysinfo::Signal::Kill); 
                }
            }
        }
    }
}

fn main() -> Result<(), Box<dyn Error>> {
    std::panic::set_hook(Box::new(|panic_info| {
        let _ = disable_raw_mode();
        let _ = execute!(io::stdout(), LeaveAlternateScreen);
        eprintln!("Application crashed: {}", panic_info);
    }));

    enable_raw_mode()?;
    let mut stdout = io::stdout();
    execute!(stdout, EnterAlternateScreen)?;
    let backend = CrosstermBackend::new(stdout);
    let mut terminal = Terminal::new(backend)?;

    let mut app = App::new();
    let tick_rate = Duration::from_millis(500);
    let mut last_tick = Instant::now();

    loop {
        terminal.draw(|f| ui(f, &mut app))?;

        let timeout = tick_rate
            .checked_sub(last_tick.elapsed())
            .unwrap_or_else(|| Duration::from_secs(0));

        if event::poll(timeout)? {
            if let Event::Key(key) = event::read()? {
                match key.code {
                    KeyCode::Char('q') => break,
                    KeyCode::Down => app.next_process(),
                    KeyCode::Up => app.previous_process(),
                    KeyCode::Char('k') => app.kill_selected_process(),
                    _ => {}
                }
            }
        }

        if last_tick.elapsed() >= tick_rate {
            app.update();
            last_tick = Instant::now();
        }
    }

    disable_raw_mode()?;
    execute!(terminal.backend_mut(), LeaveAlternateScreen)?;
    terminal.show_cursor()?;

    Ok(())
}

fn ui(f: &mut ratatui::Frame, app: &mut App) {
    let chunks = Layout::default()
        .direction(Direction::Vertical)
        .constraints([Constraint::Percentage(20), Constraint::Percentage(80)])
        .split(f.size());

    let top_chunks = Layout::default()
        .direction(Direction::Horizontal)
        .constraints([Constraint::Percentage(50), Constraint::Percentage(50)])
        .split(chunks[0]);

    let cpu_usage = app.sys.global_cpu_info().cpu_usage();
    let cpu_gauge = Gauge::default()
        .block(Block::default().title(" CPU Usage (Global) ").borders(Borders::ALL))
        .gauge_style(Style::default().fg(Color::Green).bg(Color::Black).add_modifier(Modifier::BOLD))
        .percent(cpu_usage as u16);
    f.render_widget(cpu_gauge, top_chunks[0]);

    let total_mem = app.sys.total_memory() as f64;
    let used_mem = app.sys.used_memory() as f64;
    let mem_percentage = if total_mem > 0.0 { (used_mem / total_mem) * 100.0 } else { 0.0 };
    
    let total_gb = total_mem / 1024.0 / 1024.0 / 1024.0;
    let used_gb = used_mem / 1024.0 / 1024.0 / 1024.0;

    let ram_gauge = Gauge::default()
        .block(Block::default().title(format!(" RAM: {:.1}GB / {:.1}GB ", used_gb, total_gb)).borders(Borders::ALL))
        .gauge_style(Style::default().fg(Color::Cyan).bg(Color::Black).add_modifier(Modifier::BOLD))
        .percent(mem_percentage as u16);
    f.render_widget(ram_gauge, top_chunks[1]);

    let header_cells = vec!["PID", "Process Name", "CPU %", "Memory (MB)"];
    let header = Row::new(header_cells)
        .style(Style::default().fg(Color::Yellow).add_modifier(Modifier::BOLD))
        .bottom_margin(1);

    let rows: Vec<Row> = app
        .process_list
        .iter()
        .map(|(pid, name, cpu, mem)| {
            Row::new(vec![
                pid.to_string(),
                name.clone(),
                format!("{:.1}", cpu),
                mem.to_string(),
            ])
        })
        .collect();

    let (title_text, title_style) = if app.warning.is_some() {
        ("Cannot kill System task with hrust!,System task Protection", Style::default().fg(Color::Red).add_modifier(Modifier::BOLD))
    } else {
        (" Real-time Task/Process(↑/↓: Move | K: End Task | Q: Exit) ", Style::default().fg(Color::White))
    };

    let process_table = Table::new(rows, &[
        Constraint::Percentage(15),
        Constraint::Percentage(45),
        Constraint::Percentage(20),
        Constraint::Percentage(20),
    ])
    .header(header)
    .block(Block::default()
        .title(title_text)
        .title_style(title_style)
        .borders(Borders::ALL)
        .border_style(if app.warning.is_some() { Style::default().fg(Color::Red) } else { Style::default().fg(Color::White) })
    )
    .highlight_style(Style::default().bg(Color::Blue).fg(Color::White).add_modifier(Modifier::BOLD));

    f.render_stateful_widget(process_table, chunks[1], &mut app.table_state);
}
