use sysinfo::{Disks, System};
use display_info::DisplayInfo; // <-- Add this

fn main() {
    // Initialize system information
    let mut sys = System::new_all();
    sys.refresh_all();

    // 1. OS & Host Information
    let os_name = System::name().unwrap_or_else(|| "Unknown".to_string());
    let os_ver = System::os_version().unwrap_or_else(|| "Unknown".to_string());
    let kernel = System::kernel_version().unwrap_or_else(|| "Unknown".to_string());
    let host = System::host_name().unwrap_or_else(|| "Unknown".to_string());

    // 2. CPU Information
    let cpu_brand = sys.cpus().first().map(|c| c.brand()).unwrap_or("Unknown CPU");
    let cpu_cores = sys.cpus().len();
    let cpu_freq = sys.cpus().first().map(|c| c.frequency()).unwrap_or(0);

    // 3. Memory Information (Convert bytes to GB)
    let total_mem = sys.total_memory() as f64 / 1_073_741_824.0;
    let used_mem = sys.used_memory() as f64 / 1_073_741_824.0;

    // 4. Disk Information (First disk only)
    let disks = Disks::new_with_refreshed_list();
    let disk_info = if let Some(disk) = disks.first() {
        let total = disk.total_space() as f64 / 1_073_741_824.0;
        let free = disk.available_space() as f64 / 1_073_741_824.0;
        let used = total - free;
        format!("{:.1} GB / {:.1} GB", used, total)
    } else {
        "Unknown".to_string()
    };

    // 5. GPU Information
    let gpu_info = match gfxinfo::active_gpu() {
        Ok(gpu) => format!("{} {}", gpu.vendor(), gpu.model()),
        Err(_) => "Unknown GPU".to_string(),
    };

    // 6. Display Resolution Information (NEW)
    let mut display_str = "Unknown".to_string();
    if let Ok(displays) = DisplayInfo::all() {
        if let Some(primary) = displays.first() {
            // Formats it as "1920x1080 @ 60Hz"
            display_str = format!("{}x{} @ {}", primary.width, primary.height, primary.friendly_name);
        }
    }

    // 7. Uptime
    let uptime = System::uptime();
    let uptime_hours = uptime / 3600;
    let uptime_mins = (uptime % 3600) / 60;
    let uptime_str = if uptime_hours > 0 {
        format!("{} hours, {} mins", uptime_hours, uptime_mins)
    } else {
        format!("{} mins", uptime_mins)
    };

    // Print Output with Ferris the Crab
    println!("      _~^~^~_       OS:       {} ({})", os_name, os_ver);
    println!("  \\) /  o o  \\ (/)  Kernel:   {}", kernel);
    println!("    '_   -   _'     Host:     {}", host);
    println!("    / '-----' \\     Uptime:   {}", uptime_str);
    println!("                   CPU:      {} ({} cores) @ {} MHz", cpu_brand, cpu_cores, cpu_freq);
    println!("                   GPU:      {}", gpu_info);
    println!("                   Display:  {}", display_str);
    println!("                   Memory:   {:.1} GB / {:.1} GB", used_mem, total_mem);
    println!("                   Disk:     {}", disk_info);
    println!("\nRustfetch | Written in Rust");
}