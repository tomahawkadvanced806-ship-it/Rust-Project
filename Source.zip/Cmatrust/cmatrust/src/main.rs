use crossterm::{
    cursor,
    event::{self, Event, KeyCode},
    execute,
    style::{Color, Stylize},
    terminal::{self, EnterAlternateScreen, LeaveAlternateScreen},
};
use rand::Rng;
use std::fmt::Write as FmtWrite;
use std::io::{self, Write};
use std::time::{Duration, Instant};

struct Column {
    x: u16,
    y: i16,
    speed: i16,
    ticks: i16,
    len: i16,
    chars: Vec<char>,
}

impl Column {
    fn new(x: u16, max_height: u16) -> Self {
        let mut rng = rand::thread_rng();
        let len = rng.gen_range(5..max_height as i16 / 2 + 5);
        let chars: Vec<char> = (0..len)
            .map(|_| rng.gen_range(33..126) as u8 as char)
            .collect();

        Self {
            x,
            y: rng.gen_range(-20..0),
            speed: rng.gen_range(1..3), // Slightly faster baseline speed
            ticks: 0,
            len,
            chars,
        }
    }

    fn update(&mut self, max_height: u16) {
        self.ticks += 1;
        if self.ticks >= self.speed {
            self.ticks = 0;
            self.y += 1;

            let mut rng = rand::thread_rng();
            if rng.gen_bool(0.1) {
                let idx = rng.gen_range(0..self.len as usize);
                self.chars[idx] = rng.gen_range(33..126) as u8 as char;
            }

            if self.y - self.len > max_height as i16 {
                *self = Column::new(self.x, max_height);
            }
        }
    }
}

fn main() -> io::Result<()> {
    let mut stdout = io::stdout();
    terminal::enable_raw_mode()?;
    execute!(stdout, EnterAlternateScreen, cursor::Hide)?;

    let (mut width, mut height) = terminal::size()?;
    let mut columns: Vec<Column> = (0..width).map(|x| Column::new(x, height)).collect();

    // Target 60 FPS for buttery smooth updates
    let target_fps = 60;
    let frame_duration = Duration::from_millis(1000 / target_fps);
    
    // Pre-allocate a large text rendering buffer string
    let mut buffer = String::with_capacity((width * height * 15) as usize);

    'main_loop: loop {
        let start_time = Instant::now();

        if event::poll(Duration::from_millis(0))? {
            match event::read()? {
                Event::Key(key_event) => {
                    if key_event.code == KeyCode::Char('q') || key_event.code == KeyCode::Esc {
                        break 'main_loop;
                    }
                }
                Event::Resize(w, h) => {
                    width = w;
                    height = h;
                    columns = (0..width).map(|x| Column::new(x, height)).collect();
                    buffer = String::with_capacity((width * height * 15) as usize);
                }
                _ => {}
            }
        }

        // 1. Update columns
        for col in &mut columns {
            col.update(height);
        }

        // 2. Build the frame purely in CPU memory (No terminal I/O yet)
        buffer.clear();
        
        // Reset cursor positions and paint background
        let _ = write!(buffer, "{}{}", cursor::MoveTo(0, 0), terminal::Clear(terminal::ClearType::All));

        for col in &columns {
            for i in 0..col.len {
                let cell_y = col.y - i;
                if cell_y >= 0 && cell_y < height as i16 {
                    let character = col.chars[i as usize];
                    
                    // Format ANSI escape codes directly into string memory
                    let _ = write!(buffer, "{}", cursor::MoveTo(col.x, cell_y as u16));
                    if i == 0 {
                        let _ = write!(buffer, "{}", character.white().bold());
                    } else if i < 3 {
                        let _ = write!(buffer, "{}", character.green().bold());
                    } else {
                        let _ = write!(buffer, "{}", character.with(Color::Rgb { r: 0, g: 120, b: 0 }));
                    }
                }
            }
        }

        // 3. Write the entire screen layout in one single batch action
        stdout.write_all(buffer.as_bytes())?;
        stdout.flush()?;

        let elapsed = start_time.elapsed();
        if elapsed < frame_duration {
            std::thread::sleep(frame_duration - elapsed);
        }
    }

    execute!(stdout, LeaveAlternateScreen, cursor::Show)?;
    terminal::disable_raw_mode()?;
    Ok(())
}
